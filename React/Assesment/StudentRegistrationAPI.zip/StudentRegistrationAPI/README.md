Web Application Development 
     The Department of Computer Science requires a backend application to manage student 
course registrations.  
     Develop a REST API that allows administrators to add, retrieve, and delete student 
registration records. 
     Only the backend implementation is required. 
Each registration should contain the following information. 
    
    Field           Data Type 
    >REGISTRATION_ID : Number 
    >STUDENT_NAME String 
    >STUDENT_EMAIL String 
    >COURSE_CODE String 
    >COURSE_NAME String 
    >SEMESTER : String
    >YEAR : Number
    >CREDITS : Number 
    
     
StudentRegistrationAPI/ 
│ 
├── models/ 
│      Registration.js 
│ 
├── routes/ 
│      api.js 
│ 
├── server.js 
├── package.json 
└── README.md



I create a dabase in mongoDB compass name as UniversityDB with collection name as Students. i also add 50 student datas.