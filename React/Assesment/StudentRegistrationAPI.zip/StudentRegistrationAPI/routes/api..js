const express = require('express');
const router = express.Router();
const Student = require('../models/Registration');

router.post('/save', async (req, res) => {
  try {
    const newStudent = new Student(req.body);
    const savedStudent = await newStudent.save();

    res.status(201).json({
      message: 'Student saved successfully',
      student: savedStudent,
    });
  } catch (error) {
    console.error('Error saving student:', error);
    res.status(500).json({ message: 'Failed to save student', error: error.message });
  }
});

router.post('/saveStudent', async (req, res) => {
  try {
    const newStudent = new Student(req.body);
    const savedStudent = await newStudent.save();

    res.status(201).json({
      message: 'Student saved successfully via saveStudent',
      student: savedStudent,
    });
  } catch (error) {
    console.error('Error saving student via saveStudent:', error);
    res.status(500).json({ message: 'Failed to save student via saveStudent', error: error.message });
  }
});

router.get('/findAllStudent', async (req, res) => {
  try {
    const students = await Student.find();

    res.status(200).json({
      message: 'All students fetched successfully',
      students,
    });
  } catch (error) {
    console.error('Error fetching all students:', error);
    res.status(500).json({ message: 'Failed to fetch all students', error: error.message });
  }
});

router.get('/findFirstStudent', async (req, res) => {
  try {
    const student = await Student.findOne();

    if (!student) {
      return res.status(404).json({ message: 'No student found' });
    }

    res.status(200).json({
      message: 'First student fetched successfully',
      student,
    });
  } catch (error) {
    console.error('Error fetching first student:', error);
    res.status(500).json({ message: 'Failed to fetch first student', error: error.message });
  }
});

router.delete('/delete/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deletedStudent = await Student.findByIdAndDelete(id);

    if (!deletedStudent) {
      return res.status(404).json({ message: 'Student not found for given ID' });
    }

    res.status(200).json({
      message: 'Student deleted successfully using ID route',
      deletedStudent,
    });
  } catch (error) {
    console.error('Error deleting student by ID:', error);
    res.status(500).json({ message: 'Failed to delete student by ID', error: error.message });
  }
});

router.post('/delete', async (req, res) => {
  try {
    const { _id } = req.body;

    if (!_id) {
      return res.status(400).json({ message: 'Missing required field: _id' });
    }

    const deletedStudent = await Student.findByIdAndDelete(_id);

    if (!deletedStudent) {
      return res.status(404).json({ message: 'Student not found for the provided _id' });
    }

    res.status(200).json({
      message: 'Student deleted successfully using _id in request body',
      deletedStudent,
    });
  } catch (error) {
    console.error('Error deleting student by _id:', error);
    res.status(500).json({ message: 'Failed to delete student', error: error.message });
  }
});

module.exports = router;