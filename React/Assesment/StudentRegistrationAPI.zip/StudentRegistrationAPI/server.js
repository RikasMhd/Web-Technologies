const express = require('express');
const mongoose = require('mongoose');
const studentApi = require('./routes/api..js');
const Student = require('./models/Registration');

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const uri = 'mongodb://localhost:27017/UniversityDB';

mongoose.connect(uri)
  .then(() => {
    console.log('Successfully connected to MongoDB.');
    return seedDefaultStudent();
  })
  .catch((error) => {
    console.error('Database connection error:', error);
  });

async function seedDefaultStudent() {
  try {
    const existingStudent = await Student.findOne({ REGISTRATION_ID: 1001 });

    if (!existingStudent) {
      const defaultStudent = new Student({
        REGISTRATION_ID: 1001,
        STUDENT_NAME: 'John Doe',
        STUDENT_EMAIL: 'john.doe@uni.edu',
        COURSE_CODE: 'CS101',
        COURSE_NAME: 'Introduction to Computer Science',
        SEMESTER: 'Fall',
        YEAR: 2026,
        CREDITS: 3,
      });

      await defaultStudent.save();
      console.log('Hard-coded student inserted into MongoDB.');
    } else {
      console.log('Default student already exists in MongoDB.');
    }
  } catch (error) {
    console.error('Error inserting default student:', error);
  }
}

app.use('/student', studentApi);

app.listen(port, () => {
  console.log(`Server is listening on port: ${port}`);
});