const mongoose = require('mongoose')
const StudentModel = new mongoose.Schema({
    REGISTRATION_ID: Number,
    STUDENT_NAME: String,
    STUDENT_EMAIL: String,
    COURSE_CODE:String,
    COURSE_NAME: String,
    SEMESTER: String,
    YEAR: Number,
    CREDITS: Number,
    
});
module.exports = mongoose.model(
    'Students',StudentModel,'Students'
);